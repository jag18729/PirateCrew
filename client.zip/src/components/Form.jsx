import React, { useEffect, useState } from 'react'
import axios from 'axios';
export default props => {
  const { onSubmitProp, errors } = props;

  const [name, setName] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [number, setNumber] = useState('');
  const [phrase, setPhrase] = useState('');

  const [pegLeg, setPegLeg] = useState(true);
  const [eyepatch, setEyePatch] = useState(true);
  const [hookhand, setHookHand] = useState(true);

  const positions = [
    'First Mate',
    'Quarter Master',
    'Boatswain',
    'Powder Monkey'
  ];
  const [selectedPosition, setSelectedPosition] = useState(positions[0]);
  const onSubmitHandler = e => {
    e.preventDefault();
    onSubmitProp({ name, imageUrl, number, phrase, selectedPosition, pegLeg, eyepatch, hookhand })
  }
  return (
    <div>
      <form onSubmit={onSubmitHandler}>
        {errors.map((err, index) => <h2 key={index}>{err}</h2>)}
        <p>
          <label>Name</label>
          <input type="text" value={name} onChange={e => setName(e.target.value)} />
        </p>
        <p>
          <label>Image Url:</label>
          <input type="text" value={imageUrl} onChange={e => setImageUrl(e.target.value)} />
        </p>
        <p>
          <label># of Treasure Chests:</label>
          <input type="number" value={number} onChange={e => setNumber(e.target.value)} />
        </p>
        <p>
          <label>Pirate Catch Phrases:</label>
          <input type="text" value={phrase} onChange={e => setPhrase(e.target.value)} />
        </p>
        <label>Crew position:</label>
        <label >Crew Position: </label>
        <select value={selectedPosition} onChange={e => setSelectedPosition(e.target.value)}>
          {positions.map((position, idx) => (
            <option key={idx} value={position}>{position}</option>
          ))}
        </select>
        <ul></ul>
        <li>Peg Leg: <input
          type="checkbox"
          checked={pegLeg.completed}
          onChange={e => setPegLeg(e.target.value)}></input>
        </li>
        <li>Eye Patch: <input
          type="checkbox"
          checked={eyepatch.completed}
          onChange={e => setEyePatch(e.target.value)}></input>
        </li>
        <li>Hook Hand: <input
          type="checkbox"
          checked={hookhand.completed}
          onChange={e => setHookHand(e.target.value)}></input>
        </li>
        <input type="submit" />
      </form >
    </div >
  )
}