import React, { useEffect, useState } from 'react'
import { Link } from '@reach/router';
import axios from 'axios';
import DeleteButton from './DeleteButton';
export default props => {
  const { removeFromDom } = props;
  // const removeFromDom = (pirateId) => {
  //   axios.delete('http://localhost:8000/api/author/' + authorId)
  //     .then(res => {
  //       removeFromDom(authorId)
  //     })
  // }
  return (
    <div>
      {props.pirates.map((pirate, idx) => {
        return (
          <p key={idx}>
            {pirate.name}
            <button to={"/pirate/" + pirate._id}>
              View Pirate
            </button>
            {/* <Link to={"/pirate/" + pirate._id + "/edit"}>
              Edit
            </Link> */}
            <DeleteButton pirateId={pirate._id} handleClick={removeFromDom} />
          </p>
        )
      })}
    </div>
  )
}
