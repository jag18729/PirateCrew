import './App.css';
import React from 'react';
import { Router } from '@reach/router';
import Main from './views/Main';
import ShowPirate from './views/ShowPirate';
import NewPirate from './views/NewPirate';
function App() {

  return (
    <div className="App">
      <Router>
        <Main path="/pirates" />
        <ShowPirate path="/pirates/:id" />
        <NewPirate path="/pirates/new/" />
      </Router>
    </div>
  );
}
export default App;