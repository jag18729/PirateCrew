import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { Link } from '@reach/router';
export default props => {
  const [pirate, setPirate] = useState({})
  useEffect(() => {
    axios.get("http://localhost:8000/api/pirate/" + props.id)
      .then(res => setPirate(res.data))
  }, [])
  return (
    <div>
      <p> Name: {pirate.name}</p>
      <Link to={"/pirate/" + pirate._id + "/edit"}>
        Edit
      </Link>
    </div>
  )
}
