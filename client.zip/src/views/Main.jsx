import React, { useEffect, useState } from 'react'
import axios from 'axios';
import List from '../components/List';
import { Link } from '@reach/router';

const Main = (props) => {
  const [pirates, setPirates] = useState([]);
  const [loaded, setLoaded] = useState(false);
  useEffect(() => {
    axios.get('http://localhost:8000/api/pirates')
      .then(res => {
        setPirates(res.data);
        setLoaded(true);
      });
  }, []);
  const removeFromDom = authorId => {
    setPirates(pirates.filter(author => author._id != authorId));
  }

  return (
    <div>
      <h1>Pirate Crew</h1>
      <Link to={"/pirates/new"}>Add a pirate</Link>
      <h3>We have quotes by:</h3>
      {loaded && <List pirates={pirates} removeFromDom={removeFromDom} setPirates={setPirates} />}
    </div>
  )
}

export default Main;
